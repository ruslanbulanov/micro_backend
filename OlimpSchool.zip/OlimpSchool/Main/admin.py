from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Coach)
admin.site.register(Sportsman)
admin.site.register(Parent)
admin.site.register(Primary)
admin.site.register(UMO)
admin.site.register(Rank)
admin.site.register(Sport_type)
admin.site.register(Survey)
