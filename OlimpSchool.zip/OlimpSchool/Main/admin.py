from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Coach)
admin.site.register(Sportsman)
admin.site.register(Parent)
admin.site.register(PDK)
admin.site.register(UMO)
admin.site.register(Functional_potential)
admin.site.register(Physique)
admin.site.register(Sport_type)
admin.site.register(Previous_sport)
admin.site.register(Anthropometry)
admin.site.register(Tanita)
admin.site.register(Strength_assessment)
admin.site.register(Respiratory_assessment)
admin.site.register(Physical_indicators)
admin.site.register(PWC)
admin.site.register(ECG)
admin.site.register(Stabilometry_Romberg)
admin.site.register(Psychophysiological_testing)
admin.site.register(Omega3_cardiointelography)
admin.site.register(System_analysis)
admin.site.register(PowerPANO)
admin.site.register(Speed_power_legs)