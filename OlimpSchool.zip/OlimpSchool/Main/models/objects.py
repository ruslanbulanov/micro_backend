from django.db import models
from .directories import *

GENDER = (
    ('М', 'М'),
    ('Ж', 'Ж'),
)

SCHOOL_PROGRESS = (
    ('Отл.', 'Отл.'),
    ('Хор.', 'Хор.'),
    ('Удов', 'Удов'),
)

PARENT_STATUS = (
    ('Родитель', 'Родитель'),
    ('Опекун', 'Опекун'),
    ('Иное', 'Иное'),
)

NERVOUS_SYSTEM_POTENTIAL = (
    ('Слабая', 'Слабая'),
    ('Средне-слабая', 'Средне-слабая'),
    ('Средняя', 'Средняя'),
    ('Средне-сильная', 'Средне-сильная'),
    ('Сильная', 'Сильная'),
)

MOTIVATION = (
    ('Низкая', 'Низкая'),
    ('Средняя', 'Средняя'),
    ('Высокая', 'Высокая'),
)

WILLED_QUALITIES = (
    ('Не развитый', 'Не развитый'),
    ('Низкий', 'Низкий'),
    ('Высокий', 'Высокий'),
)


class Coach(models.Model):
    name = models.CharField(max_length=150, verbose_name="Имя")
    surname = models.CharField(max_length=150, verbose_name="Фамилия")
    patronymic = models.CharField(max_length=150, verbose_name="Отчество")
    telephone = models.CharField(max_length=12, verbose_name="Контактный номер")
    sport_type = models.ForeignKey(Sport_type, on_delete=models.CASCADE, verbose_name="Вид спорта")

    def __str__(self):
        return "%s %s" % (self.id, self.surname)

    class Meta:
        ordering = ("surname",)
        verbose_name = "Тренер"
        verbose_name_plural = "Тренера"


class Parent(models.Model):
    name = models.CharField(max_length=150, verbose_name="Имя")
    surname = models.CharField(max_length=150, verbose_name="Фамилия")
    patronymic = models.CharField(max_length=150, verbose_name="Отчество")
    status = models.CharField(max_length=15, choices=PARENT_STATUS, verbose_name="Статус представителя")
    telephone = models.CharField(max_length=12, verbose_name="Контактный номер")
    email = models.EmailField(max_length=254, blank=True, verbose_name="Электронная почта")

    def __str__(self):
        return "%s %s" % (self.id, self.surname)

    class Meta:
        ordering = ("surname",)
        verbose_name = "Представитель"
        verbose_name_plural = "Представители"


class Sportsman(models.Model):
    name = models.CharField(max_length=150, verbose_name="Имя")
    surname = models.CharField(max_length=150, verbose_name="Фамилия")
    patronymic = models.CharField(max_length=150, verbose_name="Отчество")
    date_of_birth = models.DateField(auto_now_add=True, verbose_name="Дата рождения")
    gender = models.CharField(max_length=10, choices=GENDER, verbose_name="Пол")
    location = models.TextField(verbose_name="Место жительства")
    telephone = models.CharField(max_length=12, verbose_name="Контактный номер")
    swimming_skills = models.BooleanField(blank=True, verbose_name="Умение плавать")
    school_progress = models.CharField(max_length=4, choices=SCHOOL_PROGRESS, verbose_name="Успеваемость в школе")
    sport_desire = models.BooleanField(blank=True, verbose_name="Жедание заниматься спортом")
    coach = models.ForeignKey(Coach, on_delete=models.CASCADE, verbose_name="Тренер")
    parent = models.ForeignKey(Parent, on_delete=models.CASCADE, verbose_name="Представитель")
    sport_type = models.ManyToManyField(Sport_type, verbose_name="Вид спорта")

    def __str__(self):
        return "%s %s %s" % (self.id, self.surname, self.name)

    class Meta:
        ordering = ("surname",)
        verbose_name = "Спортсмен"
        verbose_name_plural = "Спортсмены"


class PDK(models.Model):
    date_of_test = models.DateField(auto_now_add=True, verbose_name="Дата прохождения тестирования")
    parent = models.ForeignKey(Parent, on_delete=models.CASCADE, verbose_name="Представитель")
    sportsman = models.ForeignKey(Sportsman, on_delete=models.CASCADE, verbose_name="Участник тестир.")
    place_of_birth = models.TextField(verbose_name="Место рождения")
    place_of_study = models.CharField(max_length=300, verbose_name="Место обучения")
    previous_sport = models.ForeignKey(Previous_sport, on_delete=models.CASCADE, verbose_name="Предыдущ. вид спорта")
    sports_facility = models.CharField(max_length=250, verbose_name="Спортивное учреждение")
    coach = models.ForeignKey(Coach, on_delete=models.CASCADE, verbose_name="Тренер")
    past_diseases = models.CharField(max_length=250, verbose_name="Перенесенные заболевания(травмы)")
    physique_of_father = models.ForeignKey(Physique, related_name='body_father', on_delete=models.CASCADE,
                                           verbose_name="Тип телосложения отца")
    physique_of_mother = models.ForeignKey(Physique, related_name='body_mother', on_delete=models.CASCADE,
                                           verbose_name="Тип телосложения матери")
    anthropometry = models.ForeignKey(Anthropometry, on_delete=models.CASCADE, verbose_name="Антропометрия")
    tanita = models.ForeignKey(Tanita, on_delete=models.CASCADE, verbose_name="TANITA")
    strength_assessment = models.ForeignKey(Strength_assessment, on_delete=models.CASCADE,
                                            verbose_name="Оценка сил.способ.")
    respiratory_assessment = models.ForeignKey(Respiratory_assessment, on_delete=models.CASCADE,
                                               verbose_name="Оценка функц.сост.органов дыхания")
    arterial_pressure_f = models.DecimalField(max_digits=4, decimal_places=1,
                                              verbose_name="Артериальное давление(первое число)")  # Вверхнее число
    arterial_pressure_s = models.DecimalField(max_digits=4, decimal_places=1,
                                              verbose_name="Артериальное давление(второе число)")  # Нижнее число
    chest_shape = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Форма грудной клетки")
    back_shape = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Форма спины")
    physical_indicators = models.ForeignKey(Physical_indicators, on_delete=models.CASCADE,
                                            verbose_name="Общие физические показатели")
    nervous_system_potential = models.CharField(max_length=15, choices=NERVOUS_SYSTEM_POTENTIAL,
                                                verbose_name="Потенциал нервной системы")
    run_30 = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Бег 30м")
    jump_place = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Прыжок в длину с места")
    pull_ups = models.PositiveIntegerField(verbose_name="Подтягивания на перекладине")
    concept = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Концепт(техническая гребля)")
    run_1500 = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Бег 1500м")
    concept_500 = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Концепт 500м")
    motivation = models.CharField(max_length=15, choices=MOTIVATION, verbose_name="Мотивация к тренеровочному процессу")
    willed_qualities = models.CharField(max_length=15, choices=WILLED_QUALITIES,
                                        verbose_name="Развитие волевых качеств")
    recommendations = models.ManyToManyField(Sport_type, verbose_name="Рекомендации")

    def __str__(self):
        return "%s %s" % (self.date_of_test, self.sportsman.surname)

    class Meta:
        ordering = ("date_of_test",)
        verbose_name = "ПДК"
        verbose_name_plural = "ПДК"


class UMO(models.Model):
    coach = models.ForeignKey(Coach, on_delete=models.CASCADE, verbose_name="Тренер")
    sportsman = models.ForeignKey(Sportsman, on_delete=models.CASCADE, verbose_name="Спортсмен")
    date_of_pass = models.DateField(auto_now_add=True, verbose_name="Дата прохождения УМО")
    pdk = models.ForeignKey(PDK, on_delete=models.CASCADE, verbose_name="ПДК")
    ecg = models.ForeignKey(ECG, on_delete=models.CASCADE, verbose_name="ЭКГ")
    plantometry = models.PositiveIntegerField(verbose_name="Плантометрия")
    stabilometry_romberg = models.ForeignKey(Stabilometry_Romberg, on_delete=models.CASCADE,
                                             verbose_name="Стабилометрия(коэф.Ромберга)")
    pwc = models.ForeignKey(PWC, on_delete=models.CASCADE, verbose_name="PWC 150-170")
    psychophysiological_testing = models.ForeignKey(Psychophysiological_testing, on_delete=models.CASCADE,
                                                    verbose_name="Психофизиологическое тестирование")
    grv = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="ГРВ")
    omega3_cardiointelography = models.ForeignKey(Omega3_cardiointelography, on_delete=models.CASCADE,
                                                  verbose_name="Омега3 спорт(Кардиоинтелография)")
    system_analysis = models.ForeignKey(System_analysis, on_delete=models.CASCADE, verbose_name="Системный анализ")

    def __str__(self):
        return "%s %s" % (self.date_of_pass, self.sportsman.surname)

    class Meta:
        ordering = ("date_of_pass",)
        verbose_name = "УМО"
        verbose_name_plural = "УМО"


class Functional_potential(models.Model):
    date = models.DateField(auto_now_add=True, verbose_name="Дата")
    sportsman = models.ForeignKey(Sportsman, on_delete=models.CASCADE, verbose_name="Спортсмен")
    umo = models.ForeignKey(UMO, on_delete=models.CASCADE, verbose_name="УМО")
    powerpano = models.ForeignKey(PowerPANO, on_delete=models.CASCADE, verbose_name="МощнПАНО")
    mpk_lmin = models.DecimalField(max_digits=4, decimal_places=2, verbose_name="МПК,л/мин")
    la_max = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="La макс, ммоль/л")
    speed_power_legs = models.ForeignKey(Speed_power_legs, on_delete=models.CASCADE, verbose_name="Скор-Сил. возм.ног")
    romberg_coefficient = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Коэффициент Ромберга")
    average = models.DecimalField(max_digits=4, decimal_places=2, verbose_name="Средние(все)")
    omega = models.DecimalField(max_digits=4, decimal_places=2, verbose_name="Сигма")

    def __str__(self):
        return "%s %s" % (self.id, self.date)

    class Meta:
        ordering = ("date",)
        verbose_name = "Функциональный потенциал"
        verbose_name_plural = "Функц. потенциал"
