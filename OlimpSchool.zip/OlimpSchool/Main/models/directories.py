from django.db import models
from .objects import *


class Physique(models.Model):
    height = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Рост")
    weight = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Вес")
    body_type = models.CharField(max_length=150, verbose_name="Тип тела")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        ordering = ("body_type",)
        verbose_name = "Телосложение"
        verbose_name_plural = "Телосложение"


class Sport_type(models.Model):
    name = models.CharField(max_length=250, verbose_name="Наименование")

    def __str__(self):
        return self.name

    class Meta:
        ordering = ("name",)
        verbose_name = "Вид спорта"
        verbose_name_plural = "Виды спорта"


class Previous_sport(models.Model):
    name = models.CharField(max_length=250, verbose_name="Наименование")
    years = models.PositiveIntegerField(verbose_name="Лет")
    months = models.PositiveIntegerField(verbose_name="Месяцев")
    rank = models.PositiveIntegerField(verbose_name="Разряд")

    def __str__(self):
        return self.name

    class Meta:
        ordering = ("name",)
        verbose_name = "Предыдущий вид спорта"
        verbose_name_plural = "Предыдущий вид спорта"


class Anthropometry(models.Model):
    weight = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Вес тела (кг)")
    length = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Длина тела(см)")
    spit_leg_length = models.PositiveIntegerField(verbose_name="Длина ног от вертела(см)")
    torso_length_7 = models.DecimalField(max_digits=4, decimal_places=1,
                                         verbose_name="Длина туловища от 7-го шейного позвонка(см)")
    arm_span = models.PositiveIntegerField(verbose_name="Размах рук(см)")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Антропометрия"
        verbose_name_plural = "Антропометрия"


class Tanita(models.Model):
    tallow_mass = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="% жировой массы")
    muscle_mass = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="% мышечной массы")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "TANITA"
        verbose_name_plural = "TANITA"


class Strength_assessment(models.Model):
    deadweight_dynamometry = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Становая динамометрия")
    dynamometry_right = models.PositiveIntegerField(verbose_name="Динамометрия правой кисти(кг)")
    dynamometry_left = models.PositiveIntegerField(verbose_name="Динамометрия левой кисти(кг)")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Оценка силовых способностей"
        verbose_name_plural = "Оценки силовых способностей"


class Respiratory_assessment(models.Model):
    chest_girth_inspiration = models.DecimalField(max_digits=4, decimal_places=1,
                                                  verbose_name="Обхват грудной клетки на вдохе(см)")
    exhaling_chest = models.DecimalField(max_digits=4, decimal_places=1,
                                         verbose_name="Обхват грудной клетки на выдохе(см)")
    excursion_difference = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Экскурсия(разница)")
    spirometry_yellow = models.PositiveIntegerField(verbose_name="Спирометрия(ЖЕЛ)мл")
    breath_hold_stange = models.DecimalField(max_digits=4, decimal_places=1,
                                             verbose_name="Проба с задер.дых.на вдохе(проба Штанге)сек")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Оценка функц.сост.органов дыхания"
        verbose_name_plural = "Оценки функц.сост.органов дыхания"


class Physical_indicators(models.Model):
    speed = models.PositiveIntegerField(verbose_name="Скорость%")
    strength = models.PositiveIntegerField(verbose_name="Сила%")
    stamina = models.PositiveIntegerField(verbose_name="Выносливость%")
    coordination = models.PositiveIntegerField(verbose_name="Координация%")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Общие физ.показатели"
        verbose_name_plural = "Общие физ.показатели"


class PWC(models.Model):
    kg = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Кг мм")
    chss = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="ЧСС")
    mpc = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="МПК мл/мин/кг")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "PWC 150-170"
        verbose_name_plural = "PWC 150-170"


class ECG(models.Model):
    rest = models.PositiveIntegerField(verbose_name="В покое")
    load = models.PositiveIntegerField(verbose_name="С нагрузкой")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "ЭКГ"
        verbose_name_plural = "ЭКГ"


class Stabilometry_Romberg(models.Model):
    open_eyes = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Открытые глаза (фон)")
    close_eyes = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Закрытые глаза")
    target = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Мишень")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Стабилометрия(коэф. Ромберга)"
        verbose_name_plural = "Стабилометрия(коэф. Ромберга)"


class Psychophysiological_testing(models.Model):
    cns_functional = models.PositiveIntegerField(verbose_name="Фукц.возможности ЦНС")
    cns_level = models.PositiveIntegerField(verbose_name="Уров.работоспособности ЦНС")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Психофизиологическое тестирование"
        verbose_name_plural = "Психофизиологическое тестирование"


class Omega3_cardiointelography(models.Model):
    golden_ratio = models.PositiveIntegerField(verbose_name="Золотое сечение(0,16-0,62)")
    voltage_index = models.PositiveIntegerField(verbose_name="Индекс напряжения")
    spectral_analysis = models.PositiveIntegerField(verbose_name="Спектральный анализ")
    integral_indicator = models.PositiveIntegerField(verbose_name="Интегральный показатель")
    adaptive_capabilities = models.PositiveIntegerField(verbose_name="Адаптационные возм.организма")
    functional_reserves = models.PositiveIntegerField(verbose_name="Функциональные резервы")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Омега3 спорт(Кардиоинтелография)"
        verbose_name_plural = "Омега3 спорт(Кардиоинтелография)"


class System_analysis(models.Model):
    power_supply = models.PositiveIntegerField(verbose_name="Энергетическое обеспечение")
    psychoemotional_state = models.PositiveIntegerField(verbose_name="Психоэмоциональное состояние")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Системный анализ"
        verbose_name_plural = "Системный анализ"


class PowerPANO(models.Model):
    vt = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="Вт")
    vt_kg = models.DecimalField(max_digits=4, decimal_places=2, verbose_name="Вт/кг")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "МощнПАНО"
        verbose_name_plural = "МощнПАНО"


class Speed_power_legs(models.Model):
    potential180 = models.DecimalField(max_digits=4, decimal_places=1, verbose_name="180+120/2 град/с н (потенциал)")
    realization180 = models.DecimalField(max_digits=4, decimal_places=2,
                                         verbose_name="180+120/2 град/с н./кг(реализация)")
    speed_power_balance = models.DecimalField(max_digits=4, decimal_places=2,
                                              verbose_name="Баланс Скорость-сила 360/30 %")

    def __str__(self):
        return "%s" % self.id

    class Meta:
        verbose_name = "Скоростно-Силовые возможности ног"
        verbose_name_plural = "Скоростно-Силовые возможности ног"
